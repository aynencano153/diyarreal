clear
echo -e "\e[95m 
ROLEX HACK CAMERA HACKİNG   \e[95;1m \e[0m\n"
    echo""    
  echo -e $'\e[1;33m\e[0m\e[1;31m    ██████████\e[0m'"\e[1;37m██████████"'\e[1;33m\e[0m\e[0;32m██████████\e[0m' '\e[1;32m\e[0m\e[1;32m Camera Hacking \e[0m''\e[1;37m\e[0m\e[1;37m [v 2.1] \e[0m'                                       
  echo ""
   echo -e $'\e[1;33m\e[0m\e[1;33m  [\e[0m\e[1;32m Follow Youtube : \e[36mhttps://youtube.com/@aynencano-153\e[0m \e[1;32m\e[0m\e[1;33m]\e[0m'
   echo ""
      echo -e $'\e[1;37m\e[0m\e[1;37m    +-+-+-+-+-+-+ +-+-+-+-+-+-+-+ >>\e[0m'
      echo -e "\e[93m    |R|O|L|EX| |H|A|C|K|"      
      echo -e $'\e[1;37m\e[0m\e[1;37m    +-+-+-+-+-+-+ +-+-+-+-+-+-+-+ >>\e[0m' 
      echo -e $'\e[1;37m\e[0m\e[1;37m    +-+-+-+-+-+ >>\e[0m'
      echo -e "\e[95m    |D|İ|Y|A|R|R|E|A|L|"      
      echo -e $'\e[1;37m\e[0m\e[1;37m    +-+-+-+-+-+ >>\e[0m' 
      echo "" 
sleep 8
clear
xdg-open "https://t.me/rolexhackyedek"
echo ""
echo ""
printf "\e[31m[\e[32m★\e[31m]\e[32m Bu Araç yalnızca eğitim amaçlıdır ve bu araç tarafından yapılan yasa dışı faaliyetlerden sorumlu değiliz.\e[m "
echo ""
echo ""
read -p $'\e[1;40m\e[31m[\e[32m*\e[31m]\e[32m Onaylıyorum  \e[1;91m (Y/N) : \e[0m' option
echo""
echo""
echo""

if [[ $option == *'N'* ]]; then
clear
exit
fi
if [[ $option == *'n'* ]]; then
clear
exit
fi

clear


echo ""
printf "\e[100;330m[\e[10m **** ]\e[1;40m\e[10m diyarreal :\e[1;32m Join Telegram Channel \e[1;33m @rolexhackyedek  !\e[0m"
sleep 4
echo ""
clear
