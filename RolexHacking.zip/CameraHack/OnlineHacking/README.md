## Nasıl Çalışır?

Her şeyden önce Bu araç, saldırganın yerel ağında bir kimlik avı sitesi barındırır. Bu araç, web sitesini internet üzerinden almak için iki port yönlendirme seçeneği (NGROK veya SERVEO) sunar. Şimdi asıl noktaya gelelim, saldırganın terminali kullanarak aracı açması ve bir bağlantı oluşturması yeterlidir, Bağlantı oluşturulduğunda saldırgan bu bağlantıyı hedefe gönderir. Hedef bağlantıyı açarsa, hedef ip saldırgana aktarılacaktır. Web sitesi yüklendikten sonra, web sitesi Kamera erişimi ister ve hedef izin verdiğinde web sitesi tek tek kamera görüntüleri çeker ve Saldırgana gönderir.

## Kurulum :
#### Bağlantı: https://t.me/rolexhackyedek

## Özellikler

* İki port yönlendirme seçeneği (NGROK veya SERVEO)
* Canlı hedef görüntü.
* Kullanımı kolay
* Anonimlik verir
* Size Duyarlı Web Sitesi sağlar.
* Otomatik Kurulum (Termux).

## Araç şunlar içindir:

*Kali Linux
* Termux
* Mac os işletim sistemi
* Ubuntu
* Perrot Sec İşletim Sistemi
* GarudaLinux

## Gereksinimler :

* Daha İyi İnternet Bağlantısı
* 300 Depolama


## Bu aracı yapmak için kullanılan dil

* Bash Komut Dosyası
* HTML
* PHP
* JavaScript
* CSS

## Uyarı

**MadCam aracı yalnızca Eğitim Amaçlıdır. Herhangi bir kullanıcı MadCam Tool'u yasa dışı bir amaçla veya intikam almak için kullanırsa, bu durumda sahibi sorumlu olmayacaktır. MadCam aracının kullanımı tamamen kullanıcının sorumluluğundadır. Herhangi bir Kullanıcı MadCam aracını kötüye kullanırsa araç ve sahibi Sorumlu olmayacaktır.**